print("Hola mundo, este es mi primer proyecto en Python 😎")
